import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-register',
  templateUrl: './buyer-register.component.html',
  styleUrls: ['./buyer-register.component.css']
})
export class BuyerRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
