import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-easy-housing',
  templateUrl: './easy-housing.component.html',
  styleUrls: ['./easy-housing.component.css']
})
export class EasyHousingComponent implements OnInit {



  constructor() { }

  ngOnInit() {
  }
  }
